// src/App.js

import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import './App.css';
import CreatePostForm from './components/CreatePostForm';
import PostList from './components/PostList';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';

// --- Make sure this is your laptop's IP address! ---
const SERVER_URL = "http://172.20.10.2:3001"; // Example IP
const socket = io(SERVER_URL, {
  autoConnect: false
});

const LOCAL_STORAGE_KEY = 'resqboard.posts';

function App() {
  const [posts, setPosts] = useState(() => {
    const savedPosts = localStorage.getItem(LOCAL_STORAGE_KEY);
    return savedPosts ? JSON.parse(savedPosts) : [];
  });

  const [view, setView] = useState('main');

  useEffect(() => {
    socket.connect(); 

    socket.on('connect', () => {
      console.log('Connected to server! Syncing my posts...');
      const currentPosts = JSON.parse(localStorage.getItem(LOCAL_STORAGE_KEY)) || [];
      socket.emit('syncMyPosts', currentPosts); 
    });

    socket.on('receivePost', (receivedPost) => {
      setPosts(currentPosts => {
        if (currentPosts.find(post => post.id === receivedPost.id)) {
          return currentPosts;
        }
        return [receivedPost, ...currentPosts];
      });
    });

    return () => {
      socket.off('connect');
      socket.off('receivePost');
      socket.disconnect();
    };
  }, []); // This effect runs only once when the app starts

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(posts));
  }, [posts]);

  const handleNewPost = (postText) => {
    navigator.geolocation.getCurrentPosition((gps) => {
      const newPost = {
        id: Date.now(),
        text: postText,
        position: [gps.coords.latitude, gps.coords.longitude],
      };
      setPosts(currentPosts => [newPost, ...currentPosts]);
      socket.emit('newPost', newPost);
    }, () => alert("Could not get location. Please allow location access."));
  };

  // --- THIS IS THE CORRECTED PART ---
  if (view === 'dashboard') {
    return (
      <div className="App">
        <header className="App-header">
          <h1>Coordinator's Dashboard</h1>
          <button onClick={() => setView('main')}>Back to Main App</button>
        </header>
        <MapContainer center={[21.1458, 79.0882]} zoom={12} style={{ height: '600px', width: '100%' }}>
          <TileLayer
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          />
          {posts.filter(post => post.position).map(post => (
            <Marker key={post.id} position={post.position}>
              <Popup>{post.text}</Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>
    );
  }

  return (
    <div className="App">
      <header className="App-header">
        <h1>ResQBoard</h1>
        <p>Your offline notice board for emergencies.</p>
        <button onClick={() => setView('dashboard')}>Go to Dashboard</button>
      </header>
      <main>
        <CreatePostForm onNewPost={handleNewPost} />
        <PostList posts={posts} />
      </main>
    </div>
  );
}

export default App;