// src/components/PostList.js

import React from 'react';

function PostList({ posts }) {
  return (
    <div className="list-container">
      <h2>Notice Board</h2>
      {posts.length === 0 ? (
        <p>No posts yet. Be the first!</p>
      ) : (
        posts.map(post => (
          <div key={post.id} className="post-item">
            {post.text}
          </div>
        ))
      )}
    </div>
  );
}

export default PostList;