// src/components/CreatePostForm.js

import React, { useState } from 'react';

function CreatePostForm({ onNewPost }) {
  const [message, setMessage] = useState('');

  const handleSubmit = () => {
    if (message.trim() === '') return; // Don't submit empty posts
    onNewPost(message); // Send the new message up to the main App
    setMessage(''); // Clear the input field after submitting
  };

  return (
    <div className="form-container">
      <input
        type="text"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="Enter your need or offer..."
      />
      <button onClick={handleSubmit}>Create Post</button>
    </div>
  );
}

export default CreatePostForm;